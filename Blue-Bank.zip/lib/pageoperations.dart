// import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:teste2/homepage.dart';

class PaginaOperations extends StatefulWidget {
  @override
  State<PaginaOperations> createState() => _PaginaOperationsState();
}

class _PaginaOperationsState extends State<PaginaOperations> {
  String var_ted = '2025-60';
  TextEditingController _controller_var_tranfer = TextEditingController();
  TextEditingController _controller_valor_boleto = TextEditingController();

  _operarTED() async {
    double var_transfer = double.tryParse(_controller_var_tranfer.text) ?? 0;
    final formatoMoeda1 = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    String valor_formatado1 = formatoMoeda1.format(var_transfer);
    if (var_ted == var_ted && var_transfer > 0.0) {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              icon: Icon(Icons.verified_user_outlined),
              title: Text('Transferência concluída!'),
              content: Text('Valor: $valor_formatado1'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Icon(Icons.exit_to_app_rounded),
                ),
              ],
            );
          });

      print('Tranferência concluída');
      print('Valor: R\$ $var_transfer');
    } else {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              icon: Icon(Icons.warning_amber_sharp),
              title: Text('Transferência  não concluída!'),
              content: Text('Valor: $valor_formatado1 não permitido'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Icon(Icons.exit_to_app_rounded),
                ),
              ],
            );
          });

      print('Tranferência não concluída');
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setDouble('resultadoTED', var_transfer);
    atualizarResultadoNaTelaInicial(var_transfer);
  }

  atualizarResultadoNaTelaInicial(double novoResultado) {
    MyHomePageState telaInicialState =
        context.findAncestorStateOfType<MyHomePageState>()!;
    telaInicialState.setState(() {
      telaInicialState.var_transfer = novoResultado;
    });
  }

  _depositar() async {
    double valor_boleto = double.tryParse(_controller_valor_boleto.text) ?? 0.0;
    final formatoMoeda2 = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    String valor_formatado2 = formatoMoeda2.format(valor_boleto);

    if (valor_boleto > 0.0) {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              icon: Icon(Icons.verified_user_outlined),
              title: Text('Boleto gerado!'),
              content: Text('Valor: $valor_formatado2'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Icon(Icons.exit_to_app_rounded),
                ),
              ],
            );
          });

      print('Boleto gerado!');
      print('Valor:R\$ $valor_formatado2');
    } else {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              icon: Icon(Icons.warning_amber_sharp),
              title: Text('Boleto  não gerado!'),
              content: Text('Valor: R\$ $valor_formatado2 não permitido'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Icon(Icons.exit_to_app_rounded),
                ),
              ],
            );
          });

      print('Valor não permitido!');
    }
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setDouble('resultadoDeposito', valor_boleto);
    atualizarResultadoNaTelaInicial(valor_boleto);
  }

  aatualizarResultadoNaTelaInicial(double novoResultado) {
    MyHomePageState telaInicialState =
        context.findAncestorStateOfType<MyHomePageState>()!;
    telaInicialState.setState(() {
      telaInicialState.valor_boleto = novoResultado;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Transações Bancárias',
          style: TextStyle(fontSize: 25),
        ),
      ),
      body: Container(
          height: double.infinity,
          width: double.infinity,
          color: Color(0xffedf3fb),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.all(30),
                height: 220,
                width: 300,
                decoration: BoxDecoration(
                    color: Color(0xffb4c7d0),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Text(
                      'TED',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    SingleChildScrollView(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          TextFormField(
                            keyboardType: TextInputType.phone,
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9-]'))
                            ],
                            decoration: InputDecoration(
                                label: Text('Digite do nº da conta'),
                                hintText: 'Exemplo: 12345-00'),
                          ),
                          TextFormField(
                              controller: _controller_var_tranfer,
                              keyboardType: TextInputType.numberWithOptions(
                                  decimal: true),
                              decoration: InputDecoration(
                                  label:
                                      Text('Digite o valor da transferência'),
                                  hintText: 'Exemplo: R\$ 0,00')),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 150,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        _operarTED();
                      },
                      child: Text('Transferir'),
                    )
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.all(5),
                height: 180,
                width: 300,
                decoration: BoxDecoration(
                    color: Color(0xffb4c7d0),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Text(
                      'Depósito por boleto',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          TextFormField(
                            controller: _controller_valor_boleto,
                            keyboardType:
                                TextInputType.numberWithOptions(decimal: true),
                            decoration: InputDecoration(
                                label: Text('Digite o valor'),
                                hintText: 'Exemplo: R\$ 0,00'),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 150,
                    ),
                    ElevatedButton(
                        onPressed: () {
                          _depositar();
                        },
                        child: Text('Gerar boleto')),
                  ],
                ),
              ),
              Center(child: Text('Others')),
            ],
          )),
    );
  }
}
