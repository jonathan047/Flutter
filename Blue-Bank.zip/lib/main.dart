import 'package:flutter/material.dart';

import 'myapp.dart';

void main() => runApp(MyApp());
