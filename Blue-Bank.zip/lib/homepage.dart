// import 'dart:async';
// import 'dart:js';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:teste2/extrato.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:teste2/navbar/creditcar.dart';
// import 'package:teste2/navbar/invest.dart';
// import 'package:flutter_test/flutter_test.dart';
import 'package:teste2/pageoperations.dart';
import 'package:teste2/pagepix.dart';

// import 'pagepix.dart';
// import 'main.dart';
// import 'dart:html';

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> {
  double saldo = 0.0;
  double var_valor = 0.0;
  double var_transfer = 0.0;
  double valor_boleto = 0.0;

  @override
  void initState() {
    super.initState();
    _recuperarResultado();
  }

  _recuperarResultado() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      double var_valor = prefs.getDouble('resultadoPix') ?? 0.0;
      double var_transfer = prefs.getDouble('resultadoTED') ?? 0.0;
      double valor_boleto = prefs.getDouble('resultadoDeposito') ?? 0.0;
      saldo = -var_valor - var_transfer + valor_boleto;
    });
  }

  @override
  Widget build(BuildContext context) {
    final formatoMoeda = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    String valor_formatado = formatoMoeda.format(saldo);

    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Color(0xffedf3fb),
        child: Column(
          children: [
            Container(
              child: Container(
                margin: const EdgeInsets.all(10),
                width: 220,
                height: 95,
                decoration: BoxDecoration(
                  color: Color(0xffb4c7d0),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Center(
                    child: Text(
                      '${valor_formatado}',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Container2(),
                ),
                Container(
                  child: Container3(),
                ),
                Container(
                  child: Container4(),
                ),
              ],
            ),
            Center(
              child: CarouselSlider(
                  items: [
                    Container(
                      width: 500,
                      height: 200,
                      decoration: BoxDecoration(
                          color: Color(0xffb4c7d0),
                          borderRadius: BorderRadius.circular(10)),
                      margin: const EdgeInsets.all(10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(7.0),
                            child: Center(
                              child: Image.asset(
                                'assets/carousel_images/carousel1.jpg',
                                // fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 500,
                      height: 200,
                      decoration: BoxDecoration(
                          color: Color(0xff49b3e3),
                          borderRadius: BorderRadius.circular(10)),
                      margin: const EdgeInsets.all(10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(34.0),
                            child: Center(
                              child: Image.asset(
                                'assets/carousel_images/image2.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 500,
                      height: 200,
                      decoration: BoxDecoration(
                          color: Color(0xff063d70),
                          borderRadius: BorderRadius.circular(10)),
                      margin: const EdgeInsets.all(10),
                      child: Center(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset(
                                'assets/carousel_images/blue.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  options: CarouselOptions(
                    height: 200.0,
                    enlargeCenterPage: false,
                    autoPlay: false,
                    autoPlayInterval: Duration(seconds: 3),
                    autoPlayAnimationDuration: Duration(milliseconds: 800),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}

class Container2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => PaginaOperations()));
      },
      child: Container(
        margin: const EdgeInsets.all(10),
        width: 90,
        height: 80,
        decoration: BoxDecoration(
            color: Color(0xffb4c7d0), borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            Text(
              'Transações Bancárias',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
            Container(height: 5),
            Container(
              child: Icon(Icons.monetization_on),
            ),
          ],
        ),
      ),
    );
  }
}

class Container3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => PagePix()));
      },
      child: Container(
        margin: const EdgeInsets.all(10),
        width: 90,
        height: 80,
        decoration: BoxDecoration(
            color: Color(0xffb4c7d0), borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            Text(
              'Pix',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
            Container(height: 5),
            Container(
              child: Icon(Icons.pix),
            ),
          ],
        ),
      ),
    );
  }
}

class Container4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => Extrato()));
      },
      child: Container(
        margin: const EdgeInsets.all(10),
        width: 90,
        height: 80,
        decoration: BoxDecoration(
            color: Color(0xffb4c7d0), borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            Text(
              'Extratos',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
            Container(height: 5),
            Container(
              child: Icon(Icons.file_present),
            ),
          ],
        ),
      ),
    );
  }
}
