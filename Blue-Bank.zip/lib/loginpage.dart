// import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:teste2/bottomnavbar.dart';
import 'package:teste2/homepage.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
// import 'main.dart';

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String var_conta = '';
  String var_senha = '';
  bool _showPassword = false;

  Widget _body() {
    return Center(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Image.asset('assets/icon_credit_card/B.png'),
            Card(
              color: Color(0xffb4c7d0),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(15),
                  child: Column(
                    children: [
                      TextFormField(
                        onChanged: (text) {
                          var_conta = text;
                        },
                        keyboardType: TextInputType.phone,
                        inputFormatters: [
                          MaskTextInputFormatter(mask: '#### - ##')
                        ],
                        decoration: InputDecoration(
                            label: Text(
                              'Conta',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            hintText: 'exemplo: 12345-0'),
                      ),
                      TextFormField(
                        onChanged: (value) {
                          var_senha = value;
                        },
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          label: Text(
                            'Senha',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          hintText: 'exemplo:12345',
                          suffixIcon: GestureDetector(
                            child: Icon(_showPassword == false
                                ? Icons.visibility_off
                                : Icons.visibility),
                            onTap: () {
                              setState(() {
                                _showPassword = !_showPassword;
                              });
                            },
                          ),
                        ),
                        obscureText: _showPassword == false ? true : false,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
              onPressed: () {
                if (var_conta == '2035 - 60' && var_senha == '12345') {
                  Navigator.of(context).pushReplacementNamed('/home');
                } else {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          backgroundColor: Colors.redAccent,
                          icon: Icon(Icons.warning_amber_sharp),
                          title: Text('Acesso Negado!'),
                          content: Text(
                              'Valores de sua conta ou senha não permitidos'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Icon(Icons.exit_to_app_rounded),
                            ),
                          ],
                        );
                      });
                }
              },
              child: Text('Entrar'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        appBar: AppBar(
          // The title text which will be shown on the action bar
          title: Text('Blue bank'),
        ),
        body: SafeArea(
          child: Stack(
            children: [
              SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: Image.asset(
                    'assets/image_login/imglogin.png',
                    fit: BoxFit.cover,
                  )),
              Container(
                color: Colors.black.withOpacity(0.2),
              ),
              _body()
            ],
          ),
        ));
  }
}
