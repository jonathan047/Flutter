import 'package:flutter/material.dart';
import 'package:teste2/homepage.dart';
import 'package:teste2/navbar/creditcar.dart';
import 'package:teste2/navbar/invest.dart';
import 'package:teste2/loginpage.dart';
import 'package:teste2/main.dart';

class BottomNavigation extends StatefulWidget {
  @override
  _BottomNavigationState createState() => _BottomNavigationState();
}

int _currentindex = 0;

final List<Widget> _telas = [
  MyHomePage(),
  CreditCard(),
  Invest(),
];

class _BottomNavigationState extends State<BottomNavigation> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Blue Bank',
          style: TextStyle(fontSize: 25),
        ),
      ),
      body: _telas[_currentindex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentindex,
        onTap: (value) {
          setState(() {
            _currentindex = value;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Início',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.credit_card_rounded),
            label: 'Cartão de crédito',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.show_chart),
            label: 'Invest',
          )
        ],
      ),
    );
  }
}
