import 'package:flutter/material.dart';
import 'package:teste2/homepage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class Transacoes {
  final String descricao;
  final double preco;

  Transacoes({required this.descricao, required this.preco});
}

class Extrato extends StatefulWidget {
  @override
  State<Extrato> createState() => _ExtratoState();
}

class _ExtratoState extends State<Extrato> {
  double saldo = 0.0;
  double var_transfer = 0.0;
  double valor_boleto = 0.0;
  _recuperarResultado() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      double var_valor = prefs.getDouble('resultadoPix') ?? 0.0;
      double var_transfer = prefs.getDouble('resultadoTED') ?? 0.0;
      double valor_boleto = prefs.getDouble('resultadoDeposito') ?? 0.0;
      saldo = -var_valor - var_transfer + valor_boleto;
    });
  }

  final List<Transacoes> transacoes = [
    Transacoes(descricao: 'Comercial da Esquina Ltda', preco: -100.00),
    Transacoes(descricao: 'Depósito', preco: 2000.00),
    Transacoes(descricao: 'Shopping Mall', preco: -250.00),
    Transacoes(descricao: 'Oficina do Zé', preco: -1005.50),
    Transacoes(descricao: 'Depósito', preco: 5000.00),
    Transacoes(descricao: 'Saque', preco: -50.55),
  ];

  @override
  Widget build(BuildContext context) {
    final formatoMoeda = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    String valor_formatado = formatoMoeda.format(saldo);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Extrato',
          style: TextStyle(fontSize: 25),
        ),
      ),
      body: SafeArea(
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: Color(0xffedf3fb),
          child: SafeArea(
              child: Column(
            children: [
              Container(
                margin: const EdgeInsets.all(10),
                width: 220,
                height: 95,
                decoration: BoxDecoration(
                    color: Color(0xffb4c7d0),
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                    '$valor_formatado',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Expanded(
                  child: ListView.builder(
                      itemCount: transacoes.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(
                            transacoes[index].descricao,
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text('R\$ ${transacoes[index].preco}'),
                          leading: Icon(
                            transacoes[index].preco < 0.0
                                ? Icons.arrow_downward
                                : Icons.arrow_upward,
                            color: transacoes[index].preco < 0.0
                                ? Colors.red
                                : Colors.green,
                          ),
                        );
                      }))
            ],
          )),
        ),
      ),
    );
  }
}
