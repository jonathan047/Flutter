import 'package:flutter/material.dart';

class CreditCard extends StatefulWidget {
  // const ({ Key? key }) : super(key: key);

  @override
  State<CreditCard> createState() => _CreditCard();
}

class _CreditCard extends State<CreditCard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Color(0xffedf3fb),
        child: Column(
          children: [
            Padding(padding: const EdgeInsets.all(50)),
            Container(
              width: 500,
              height: 200,
              decoration: BoxDecoration(
                  color: Color(0xff016493),
                  borderRadius: BorderRadius.circular(10)),
              margin: const EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('assets/icon_credit_card/B.png'),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset(
                            'assets/icon_credit_card/icons8-mastercard-48.png'),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Center(
                      child: Text(
                        '0987 6543 2100 1122 5670',
                        style: TextStyle(
                          color: Color(0xffd0f2ff),
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Center(
                      child: Text(
                        'Jonathan S Barros',
                        style: TextStyle(
                            color: Color(0xffd0f2ff),
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                  decoration: BoxDecoration(color: Color(0xffb4c7d0)),
                  margin: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(''),
                      Text(''),
                    ],
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
