import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:data_table_2/data_table_2.dart';

class Invest extends StatefulWidget {
  @override
  State<Invest> createState() => _InvestState();
}

class _InvestState extends State<Invest> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Color(0xffedf3fb),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Gráfico de Ações
              Expanded(
                flex: 2,
                child: LineChart(
                  LineChartData(
                    // Configuração do gráfico
                    gridData: FlGridData(show: false),
                    titlesData: FlTitlesData(show: false),
                    borderData: FlBorderData(show: true),
                    lineBarsData: [
                      LineChartBarData(
                        spots: [
                          FlSpot(0, 3),
                          FlSpot(1, 1),
                          FlSpot(2, 4),
                          FlSpot(3, 2),
                          FlSpot(4, 5),
                        ],
                        isCurved: true,
                        colors: [Colors.blue],
                        dotData: FlDotData(show: false),
                        belowBarData: BarAreaData(show: false),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              // Tabela de Ações
              Expanded(
                flex: 3,
                child: DataTable2(
                  columns: [
                    DataColumn2(
                      label: Text('Empresa'),
                      size: ColumnSize.L,
                    ),
                    DataColumn2(
                      label: Text('Preço'),
                      size: ColumnSize.M,
                    ),
                    DataColumn2(
                      label: Text('Variação'),
                      size: ColumnSize.S,
                    ),
                  ],
                  rows: [
                    DataRow(
                      cells: [
                        DataCell(Text('Empresa A')),
                        DataCell(Text('\$50.00')),
                        DataCell(Text('+2.5%')),
                      ],
                    ),
                    DataRow(
                      cells: [
                        DataCell(Text('Empresa B')),
                        DataCell(Text('\$75.50')),
                        DataCell(Text('-1.8%')),
                      ],
                    ),
                    DataRow(
                      cells: [
                        DataCell(Text('Empresa C')),
                        DataCell(Text('\$120.00')),
                        DataCell(Text('+5.2%')),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
