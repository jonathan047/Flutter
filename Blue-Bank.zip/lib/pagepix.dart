// import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

// import 'package:teste2/bottomnavbar.dart';
import 'package:teste2/homepage.dart';

class PagePix extends StatefulWidget {
  // var valor = Container_pix1();
  @override
  State<PagePix> createState() => _PagePixState();
}

class _PagePixState extends State<PagePix> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Pix',
          style: TextStyle(fontSize: 25),
        ),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Color(0xffedf3fb),
        child: Container(
          child: Column(
            children: [
              Container(
                child: Padding(padding: const EdgeInsets.all(10)),
              ),
              Container(
                margin: const EdgeInsets.all(10),
                width: 350,
                height: 250,
                decoration: BoxDecoration(
                    color: Color(0xffb4c7d0),
                    borderRadius: BorderRadius.circular(10)),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(child: Container_pix1()),
                      Container(
                        child: Container_pix2(),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Container_pix1 extends StatefulWidget {
  @override
  State<Container_pix1> createState() => _Container_pix1State();
}

class _Container_pix1State extends State<Container_pix1> {
  TextEditingController _controller_key_pix = TextEditingController();
  TextEditingController _controller_valor = TextEditingController();

  _bottomPix1() async {
    double var_valor = double.tryParse(_controller_valor.text) ?? 0.0;
    setState(() {
      String? key_pix = _controller_key_pix.text;

      final formatoMoeda3 =
          NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
      String valor_formatado3 = formatoMoeda3.format(var_valor);
      if (var_valor > 0.00) {
        key_pix;
        var_valor - 0;

        Navigator.of(context).pop();

        showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                icon: Icon(Icons.verified_user_outlined),
                title: Text('Transferência pix concluída!'),
                content: Text('Valor: $valor_formatado3'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(Icons.exit_to_app_rounded),
                  ),
                ],
              );
            });
      } else {
        showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                icon: Icon(Icons.warning_amber_sharp),
                title: Text('Transferência pix não concluída!'),
                content: Text('Valor: $valor_formatado3 não permitido'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(Icons.exit_to_app_rounded),
                  ),
                ],
              );
            });
      }
    });
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setDouble('resultadoPix', var_valor);
    atualizarResultadoNaTelaInicial(var_valor);
  }

  atualizarResultadoNaTelaInicial(double novoResultado) {
    MyHomePageState telaInicialState =
        context.findAncestorStateOfType<MyHomePageState>()!;
    telaInicialState.setState(() {
      telaInicialState.var_valor = novoResultado;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        showBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: Color(0xffb4c7d0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Center(
                      child: Text(
                        'Digite a chave pix',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    SingleChildScrollView(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          TextFormField(
                            controller: _controller_key_pix,
                            keyboardType: TextInputType.text,
                            decoration: InputDecoration(
                              label: Text(
                                'Digite a chave pix: CPF, telefone ou e-mail',
                              ),
                              hintText:
                                  '123.403.233-00; exemplo@email.com; (00) 9999-9999',
                            ),
                          ),
                          TextFormField(
                            controller: _controller_valor,
                            keyboardType:
                                TextInputType.numberWithOptions(decimal: true),
                            decoration: InputDecoration(
                                label: Text('Digite o valor'),
                                hintText: 'R\$ 0.00'),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        _bottomPix1();
                      },
                      child: Text('Transferir'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
      child: Container(
          margin: const EdgeInsets.all(10),
          height: 100,
          width: 100,
          decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Text(
                'Transferência Instantânea',
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Color(0xffd0f2ff)),
                textAlign: TextAlign.center,
              ),
              Container(height: 10),
              Container(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.attach_money_rounded,
                    color: Color(0xffd0f2ff),
                  ),
                  Icon(
                    Icons.arrow_back_rounded,
                    color: Color(0xffd0f2ff),
                  ),
                ],
              )),
            ],
          )),
    );
  }

  @override
  void dispose() {
    _controller_key_pix.dispose();
    _controller_valor.dispose();
    super.dispose();
  }
}

class Container_pix2 extends StatefulWidget {
  @override
  State<Container_pix2> createState() => Container_pix2State();
}

class Container_pix2State extends State<Container_pix2> {
  String _scanCode = '';
  Future<void> readQRCode() async {
    String qrcoderesult;
    try {
      qrcoderesult = await FlutterBarcodeScanner.scanBarcode(
        "2196F3",
        "Cancelar",
        true,
        ScanMode.QR,
      );
      debugPrint(qrcoderesult);
    } on PlatformException {
      qrcoderesult = 'Failed for version.';
    }
    if (!mounted) return;
    setState(() {
      _scanCode = qrcoderesult;
    });
  }

  _bottomPix2(BuildContext context) {
    showBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            color: Color(0xffb4c7d0),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Center(
                  child: Text(
                    'Aponte o QR CODE',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Container(
                          height: 140,
                          width: 130,
                          color: Colors.white,
                          child: GestureDetector(
                              onTap: readQRCode,
                              child: Text('data:$_scanCode')),
                        ),
                      ],
                    )),
                SizedBox(
                  height: 50,
                  width: 50,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        return _bottomPix2(context);
      },
      child: Container(
          margin: const EdgeInsets.all(10),
          height: 100,
          width: 100,
          decoration: BoxDecoration(
              color: Colors.blue, borderRadius: BorderRadius.circular(10)),
          child: Column(
            children: [
              Text(
                'Transferência QR Code',
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Color(0xffd0f2ff)),
                textAlign: TextAlign.center,
              ),
              Container(height: 10),
              Container(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.qr_code_2_rounded,
                    color: Color(0xffd0f2ff),
                  ),
                ],
              )),
            ],
          )),
    );
  }
}
